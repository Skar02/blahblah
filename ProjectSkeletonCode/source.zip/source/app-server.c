/**
 * Handles the application, of controlling motor speed, through threads.
 *
 * @authors Josefine Nyholm, Nils Kiefer, Arunraghavendren Senthil Kumar
 * 
 * @cite https://arm-software.github.io/CMSIS-RTX/latest/rtos2_tutorial.html#rtos2_tutorial_threads
 * @cite T. Martin and M. Rogers, The designer's guide to the cortex-m processor family, Second edition. 2016.
 */

#include "main.h" 
#include "application.h" 
#include "controller.h"
#include "peripherals.h"
#include "cmsis_os2.h"
#include "socket.h"
#include "shared_protocol.h"

/* Global variables ----------------------------------------------------------*/

 int32_t reference, velocity, control;
 uint32_t millisec;
 
 int8_t  sock;		//Comunication stuff
 uint8_t sn;
 uint8_t status;
 int8_t  ret;   //stores the result of listen (successful or not)

static osThreadId_t main_id, ctrl_id, ref_id; //< Defines thread IDs
static osTimerId_t ctrl_timer, ref_timer;     //< Defines callback timers

/* Function/Thread declaration -----------------------------------------------*/

static void timerCallback(void *arg); // Callback timer function
static void init_virtualTimers(void);

static void init_threads(void);
static void app_main(void *arg);
static void app_ctrl(void *arg);
static void app_ref(void *arg);

/**
 * Defines attributes for main_id and app_main()
 */
static const osThreadAttr_t threadAttr_main = {
	.name       = "app_main",
	.stack_size = 128*4,         // Application_Loop call + waiting for flags, small call-stack => 256 bytes, with margin => 512 bytes
	.priority   = osPriorityBelowNormal
};

/**
 * Defines attributes for ctrl_id and app_ctrl()
 */
static const osThreadAttr_t threadAttr_ctrl = {
	.name       = "app_ctrl",
	.stack_size = 128*4,       // ~24 bytes local variables, ~32 bytes RTOS-functions, ~232 bytes function calls, call-stack + safety ~100 bytes
	.priority   = osPriorityNormal
};

/**
 * Defines attributes for ref_id and app_ref()
 */
static const osThreadAttr_t threadAttr_ref = {
	.name       = "app_ref",
	.stack_size = 128*2,              // ~8 bytes local variables, ~100-150 bytes RTOS-function, call-stack + safety ~100 bytes
	.priority   = osPriorityHigh
};



// Helper functions that assist with the communication
static int32_t send_all(uint8_t sn, const void *buf, uint16_t len)
{
    const uint8_t *p = (const uint8_t *)buf;
    uint16_t sent = 0;

    while (sent < len)
    {
        int32_t n = send(sn, (uint8_t *)(p + sent), (uint16_t)(len - sent));
        if (n <= 0) return n;          // error or closed
        sent = (uint16_t)(sent + (uint16_t)n);
    }
    return (int32_t)sent;
}

static int32_t recv_all(uint8_t sn, void *buf, uint16_t len)
{
    uint8_t *p = (uint8_t *)buf;
    uint16_t recvd = 0;

    while (recvd < len)
    {
        int32_t n = recv(sn, (uint8_t *)(p + recvd), (uint16_t)(len - recvd));
        if (n <= 0) return n;          // error or closed
        recvd = (uint16_t)(recvd + (uint16_t)n);
    }
    return (int32_t)recvd;
}

/* Functions -----------------------------------------------------------------*/
 
/**
 * Initializes global variables, motor, controller and threads
 */
void Application_Setup()
{
  // Reset global variables
  reference = 2000;
  velocity  = 0;
  control   = 0;
  millisec  = 0;
	
  Peripheral_GPIO_EnableMotor(); // Initialise hardware
  Controller_Reset();            // Initialize controller	
	
	osKernelInitialize();
	init_threads();                // Initializes threads
	osKernelStart();
}

/**
 * Keeps the application waiting
 */
void Application_Loop()
 {

    /* Create TCP socket on port 5000 */
    sock = socket(0, Sn_MR_TCP, 5000, 0);
    if (sock < 0) {
        for(;;) osDelay(1000);
    }
    sn = (uint8_t)sock;

    /* Listen */
    ret = listen(sn);
    if (ret != SOCK_OK) {
        close(sn);
        for(;;) osDelay(1000);
    }

    /* Wait for client connection */
    for (;;) {
        getsockopt(sn, SO_STATUS, &status);
        if (status == SOCK_ESTABLISHED) break;
        osDelay(50);
    }

    /* Start-of-session time zero (requirement) */
    uint32_t t0 = Main_GetTickMillisec();
		init_virtualTimers();			  	 // Initializes and starts virtual timers

    /* Connected session */
    for (;;) {
        getsockopt(sn, SO_STATUS, &status);
        if (status != SOCK_ESTABLISHED) {
            break;
        }
				
				//Send control first
				control  = Controller_PIController(&reference, &velocity, &millisec); // Calculate control signal
		
				if (send_all(sn, &control, (uint16_t)sizeof(control)) <= 0) {
            break;
        }

        /*Receive sample */
        Sample_t s;
        if (recv_all(sn, &s, (uint16_t)sizeof(Sample_t)) <= 0) {
            break;
        }
	
        /*Store received values */
        velocity  = s.velocity;
        millisec  = s.timestamp;
				

        
    }

    close(sn);
    //for(;;) osDelay(1000);
 }
 
 /* Virtual Timer Functions --------------------------------------------------*/
 
/**
 * Initializes the threads virtual timers to call the callback function periodically.
 */
static void init_virtualTimers(void)
{
	ctrl_timer = osTimerNew(timerCallback, osTimerPeriodic, ctrl_id, NULL); // Sets a periodic timer for app_ctrl to call the callback function
	ref_timer  = osTimerNew(timerCallback, osTimerPeriodic, ref_id, NULL);  // Sets a periodic timer for app_ref to call the callback function
	
	uint32_t tickDelay_ctrl = (PERIOD_CTRL * osKernelGetTickFreq()) / 1000; // Calculates amount of ticks representing the required period in ms
	uint32_t tickDelay_ref  = (PERIOD_REF * osKernelGetTickFreq()) / 1000;  // Calculates amount of ticks representing the required period in ms
	
	// Starts and specifies timing in system ticks
	osTimerStart(ctrl_timer, tickDelay_ctrl);
	osTimerStart(ref_timer, tickDelay_ref);
}

/**
 * Sets the correct thread flag depending on input parameted thread ID.
 *
 * @param arg - Thread ID
 */
static void timerCallback(void *arg)
{
  osThreadFlagsSet((osThreadId_t)arg, 0x01);					// Flags the correct thread through thread ID
}
 
/* Thread Functions ----------------------------------------------------------*/

/**
 * Initializes threads
 */
static void init_threads(void)
{
	main_id = osThreadNew(app_main, NULL, &threadAttr_main);
	ctrl_id = osThreadNew(app_ctrl, NULL, &threadAttr_ctrl);
	ref_id  = osThreadNew(app_ref, NULL, &threadAttr_ref);
}

/**
 * Calls Application_loop() indefinetly
 *
 * @param arg - Thread argument
 */
__NO_RETURN static void app_main(void *arg)
{
	
	for(;;)
	{
		Application_Loop();
	}
}

/* Thread Functions with Flags -----------------------------------------------*/
/**
 * Samples encoder, calculates the control signal and applies it to the motor every 10 ms, using osThreadFlagsWait().
 *
 * @param arg - Thread argument
 */

// These threads are not being used at all actually
__NO_RETURN static void app_ctrl(void *arg)
{	
	for(;;)
	{
		osThreadFlagsWait(0x01, osFlagsWaitAny, osWaitForever); // Wait for next sample flagging (flag gets rinsed automatically)
		
		control  = Controller_PIController(&reference, &velocity, &millisec); // Calculate control signal
		
		if (send_all(sn, &control, (uint16_t)sizeof(control)) <= 0) {
            break;
        }
		
		//Peripheral_PWM_ActuateMotor(control); // Apply control signal to motor
	}
}

/**
 * Toggles the direction of the reference every 4000 ms using osThreadFlagsWait().
 *
 * @param arg - Thread argument
 */
__NO_RETURN static void app_ref(void *arg)
{
	for(;;)
	{
		osThreadFlagsWait(0x01, osFlagsWaitAny, osWaitForever); // Wait for next sample flagging (flag gets rinsed automatically)
		reference = -reference;                                 // Flip reference
	}
}