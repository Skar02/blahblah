/**
 * Handles the application, of controlling motor speed, through threads.
 *
 * @authors Josefine Nyholm, Nils Kiefer, Arunraghavendren Senthil Kumar
 * 
 * @cite https://arm-software.github.io/CMSIS-RTX/latest/rtos2_tutorial.html#rtos2_tutorial_threads
 * @cite T. Martin and M. Rogers, The designer's guide to the cortex-m processor family, Second edition. 2016.
 */

#include "main.h" 
#include "application.h" 
#include "controller.h"
#include "peripherals.h"
#include "cmsis_os2.h"
#include "socket.h"
#include "shared_protocol.h"

/* Global variables ----------------------------------------------------------*/

int32_t reference, velocity, control;
uint32_t millisec;
static osThreadId_t main_id, rxtx_id, actuate_id; //< Defines thread IDs

int8_t  sock;
uint8_t sn;
uint8_t status;
int8_t  ret;

uint8_t server_ip[4] = {192, 168, 0, 10};

//For motor stopping should there be disconnect
static volatile uint32_t last_ctrl_ms = 0;


/* Function/Thread declaration -----------------------------------------------*/

static void timerCallback(void *arg); // Callback timer function
static void init_virtualTimers(void);

static void init_threads(void);
static void app_main(void *arg);
static void app_rxtx(void *arg);
static void app_actuate(void *arg);

/**
 * Defines attributes for main_id and app_main()
 */
static const osThreadAttr_t threadAttr_main = {
	.name       = "app_main",
	.stack_size = 128*4,         // Application_Loop call + waiting for flags, small call-stack => 256 bytes, with margin => 512 bytes
	.priority   = osPriorityNormal
};

/**
 * Defines attributes for rxtx_id and app_rxtx()
 */
static const osThreadAttr_t threadAttr_rxtx = {
	.name       = "app_rxtx",
	.stack_size = 128*4,       // ~24 bytes local variables, ~32 bytes RTOS-functions, ~232 bytes function calls, call-stack + safety ~100 bytes
	.priority   = osPriorityBelowNormal
};

/**
 * Defines attributes for actuate_id and app_actuate()
 */
static const osThreadAttr_t threadAttr_actuate = {
	.name       = "app_actuate",
	.stack_size = 128*2,              // ~8 bytes local variables, ~100-150 bytes RTOS-function, call-stack + safety ~100 bytes
	.priority   = osPriorityHigh
};


// Helper functions that assist with the communication
static int32_t send_all(uint8_t sn, const void *buf, uint16_t len)
{
    const uint8_t *p = (const uint8_t *)buf;
    uint16_t sent = 0;

    while (sent < len)
    {
        int32_t n = send(sn, (uint8_t *)(p + sent), (uint16_t)(len - sent));
        if (n <= 0) return n;          // error or closed
        sent = (uint16_t)(sent + (uint16_t)n);
    }
    return (int32_t)sent;
}

static int32_t recv_all(uint8_t sn, void *buf, uint16_t len)
{
    uint8_t *p = (uint8_t *)buf;
    uint16_t recvd = 0;

    while (recvd < len)
    {
        int32_t n = recv(sn, (uint8_t *)(p + recvd), (uint16_t)(len - recvd));
        if (n <= 0) return n;          // error or closed
        recvd = (uint16_t)(recvd + (uint16_t)n);
    }
    return (int32_t)recvd;
}

/* Functions -----------------------------------------------------------------*/
 
/**
 * Initializes global variables, motor, controller and threads
 */
void Application_Setup()
{
  // Reset global variables
  reference = 0;
  velocity  = 0;
  control   = 0;
  millisec  = 0;
	
  Peripheral_GPIO_EnableMotor(); // Initialise hardware
  Controller_Reset();            // Initialize controller	
	
	osKernelInitialize();
	init_threads();                // Initializes threads
	osKernelStart();
}

/**
 * Keeps the application waiting
 */
void Application_Loop()
 {
    /* Create socket */
    sock = socket(0, Sn_MR_TCP, 0, 0);
    if (sock < 0) {
        for(;;) osDelay(1000);
    }
    sn = (uint8_t)sock;

    /* Connect */
    ret = connect(sn, server_ip, 5000);
    (void)ret;

    /* Wait for connection */
    for (;;) {
        getsockopt(sn, SO_STATUS, &status);
        if (status == SOCK_ESTABLISHED){ 
					break;
				}
    }
		// signal rxtx thread to start
		// osThreadFlagsSet(rxtx_id, 0x01);

    /* Connected session */
    for (;;) {
				osThreadFlagsWait(0x01, osFlagsWaitAll, osWaitForever);
    }

    close(sn);
 }

/**
 * Initializes threads
 */
static void init_threads(void)
{
	main_id = osThreadNew(app_main, NULL, &threadAttr_main);
	rxtx_id = osThreadNew(app_rxtx, NULL, &threadAttr_rxtx);
	actuate_id = osThreadNew(app_actuate, NULL, &threadAttr_actuate);
}

/**
 * Calls Application_loop() indefinetly
 *
 * @param arg - Thread argument
 */
__NO_RETURN static void app_main(void *arg)
{
	for(;;)
	{
		Application_Loop();
	}
}

static void app_rxtx(void *arg)
{	
	
	// wait until connection ready
  // osThreadFlagsWait(0x01, osFlagsWaitAny, osWaitForever);

	for(;;)
	{
			 uint16_t rx_size = getSn_RX_RSR(sn);

				if (rx_size >= sizeof(control))
				{
						int32_t n = recv(sn, (uint8_t*)&control, sizeof(control));
						if (n == sizeof(control))
						{
								last_ctrl_ms = Main_GetTickMillisec();
								//osThreadFlagsSet(actuate_id, 0x01);
						}
				}
			 
			
				// signal actuate thread (if control successfully received)
				// osThreadFlagsSet(actuate_id, 0x01);
				
				 /* Measure new Velocity */
        Sample_t s;
        s.timestamp = Main_GetTickMillisec();
        s.velocity  = Peripheral_Encoder_CalculateVelocity(s.timestamp);
				
				/* Send measurement. If failed go into this if block */
        if (send_all(sn, &s, (uint16_t)sizeof(s)) <= 0) {
						//control = 0;
						//osThreadFlagsSet(actuate_id, 0x01);
            break;
				}
				
				
	}
}

/**
 * Toggles the direction of the reference every 4000 ms using osThreadFlagsWait().
 *
 * @param arg - Thread argument
 */

__NO_RETURN static void app_actuate(void *arg)
{for(;;)
	{
				osDelay(10);
				// wait until new control received
        //osThreadFlagsWait(0x01, osFlagsWaitAny, osWaitForever);
		
				uint32_t now = Main_GetTickMillisec();
		
				if ((now - last_ctrl_ms) >= 10) {
            Peripheral_PWM_ActuateMotor(0);
        } else {
            Peripheral_PWM_ActuateMotor(control);
        }
        
		
	}
}
