var structwiz___net_info__t =
[
    [ "dhcp", "structwiz___net_info__t.html#aff5d1c06cc07180717f38809f922fb35", null ],
    [ "dns", "structwiz___net_info__t.html#a9bf249fa42db4caf84d05f92ed1f9718", null ],
    [ "gw", "structwiz___net_info__t.html#afe459e05623fc633d44e723d33b7b1cb", null ],
    [ "ip", "structwiz___net_info__t.html#ae81515e082f9bc33e8968181945586da", null ],
    [ "mac", "structwiz___net_info__t.html#a2f32c75fb4bc7ba39243ef4a9f8eacc1", null ],
    [ "sn", "structwiz___net_info__t.html#aa73e8ce077be99a42405230770f2c731", null ]
];