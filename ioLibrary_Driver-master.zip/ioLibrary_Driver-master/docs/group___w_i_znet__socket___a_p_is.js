var group___w_i_znet__socket___a_p_is =
[
    [ "close", "group___w_i_znet__socket___a_p_is.html#gaf7c8a46c623edfab31d9e09788394b2f", null ],
    [ "connect", "group___w_i_znet__socket___a_p_is.html#gaf7ab832f4201ef0f04eefcac063b998e", null ],
    [ "ctlsocket", "group___w_i_znet__socket___a_p_is.html#gae2f94d7d4ce040f6bf68779e064d224e", null ],
    [ "disconnect", "group___w_i_znet__socket___a_p_is.html#ga0230efb936b222a0cbc7680e2c39c994", null ],
    [ "getsockopt", "group___w_i_znet__socket___a_p_is.html#ga631998ae17cbf099b0071f20c88ce5cf", null ],
    [ "listen", "group___w_i_znet__socket___a_p_is.html#ga58ae959798d5d874ac5ea796da90db8c", null ],
    [ "recv", "group___w_i_znet__socket___a_p_is.html#ga4cfb66f7440a1dd9ac0ee0b933a38c59", null ],
    [ "recvfrom", "group___w_i_znet__socket___a_p_is.html#gae580bd099f9bcbeca63a3145c0015e62", null ],
    [ "send", "group___w_i_znet__socket___a_p_is.html#gacd77c3cc60e87d09a5714932506d7c4b", null ],
    [ "sendto", "group___w_i_znet__socket___a_p_is.html#ga30fc77ba1005733b501994818bde12f8", null ],
    [ "setsockopt", "group___w_i_znet__socket___a_p_is.html#ga0111e4784e20d97dacd5aaf54cb48ef1", null ],
    [ "socket", "group___w_i_znet__socket___a_p_is.html#ga8cc0a2074b3aae98a132c1ae3c51188f", null ]
];