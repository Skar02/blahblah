var structwiz___phy_conf__t =
[
    [ "by", "structwiz___phy_conf__t.html#a210757da9e55568e0e72a280e75973f4", null ],
    [ "duplex", "structwiz___phy_conf__t.html#a9296ce83c568e13e59d7c33283886601", null ],
    [ "mode", "structwiz___phy_conf__t.html#a37e90f5e3bd99fac2021fb3a326607d4", null ],
    [ "speed", "structwiz___phy_conf__t.html#aae32029df16a54aa86c0aec2df9f7bb7", null ]
];