var struct_____w_i_z_c_h_i_p_1_1___c_s =
[
    [ "_deselect", "struct_____w_i_z_c_h_i_p_1_1___c_s.html#a7a2460cf2b0775c046fd24dcaa55c251", null ],
    [ "_select", "struct_____w_i_z_c_h_i_p_1_1___c_s.html#a797567e52e01f60a912a2ff2bde6d60f", null ]
];