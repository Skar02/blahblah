var dir_a138ed074e64356ad02dbb8d94382c4f =
[
    [ "W5500", "dir_337e147d8ae2958ef29ccaa8e2f968db.html", "dir_337e147d8ae2958ef29ccaa8e2f968db" ],
    [ "socket.c", "socket_8c.html", "socket_8c" ],
    [ "socket.h", "socket_8h.html", "socket_8h" ],
    [ "wizchip_conf.c", "wizchip__conf_8c.html", "wizchip__conf_8c" ],
    [ "wizchip_conf.h", "wizchip__conf_8h.html", "wizchip__conf_8h" ]
];