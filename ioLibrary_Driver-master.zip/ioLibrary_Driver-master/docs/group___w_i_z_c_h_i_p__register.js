var group___w_i_z_c_h_i_p__register =
[
    [ "Common register", "group___common__register__group.html", "group___common__register__group" ],
    [ "Socket register", "group___socket__register__group.html", "group___socket__register__group" ]
];