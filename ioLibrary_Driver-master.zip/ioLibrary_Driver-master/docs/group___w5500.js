var group___w5500 =
[
    [ "WIZCHIP register", "group___w_i_z_c_h_i_p__register.html", "group___w_i_z_c_h_i_p__register" ],
    [ "WIZCHIP I/O functions", "group___w_i_z_c_h_i_p___i_o___functions.html", "group___w_i_z_c_h_i_p___i_o___functions" ]
];