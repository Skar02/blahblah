var struct_____w_i_z_c_h_i_p =
[
    [ "_CRIS", "struct_____w_i_z_c_h_i_p_1_1___c_r_i_s.html", "struct_____w_i_z_c_h_i_p_1_1___c_r_i_s" ],
    [ "_CS", "struct_____w_i_z_c_h_i_p_1_1___c_s.html", "struct_____w_i_z_c_h_i_p_1_1___c_s" ],
    [ "_IF", "union_____w_i_z_c_h_i_p_1_1___i_f.html", "union_____w_i_z_c_h_i_p_1_1___i_f" ],
    [ "CRIS", "struct_____w_i_z_c_h_i_p.html#a4ddfaea37137d95f4d3dc9481d2f8796", null ],
    [ "CS", "struct_____w_i_z_c_h_i_p.html#adafc624424678d96c64f57b022605ba5", null ],
    [ "id", "struct_____w_i_z_c_h_i_p.html#a836d635c51ae68815e49464836c09912", null ],
    [ "IF", "struct_____w_i_z_c_h_i_p.html#a386996abbbf890ab44c90da5dc5c2f93", null ],
    [ "if_mode", "struct_____w_i_z_c_h_i_p.html#a756c793b5c41636ebdf090d7c4d3ea00", null ]
];