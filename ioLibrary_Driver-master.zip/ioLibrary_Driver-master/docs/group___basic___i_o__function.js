var group___basic___i_o__function =
[
    [ "wiz_recv_data", "group___basic___i_o__function.html#ga98cbcd6c7ba3abf9ab28caa8261886b1", null ],
    [ "wiz_recv_ignore", "group___basic___i_o__function.html#gaaaae8c46f0d8745e3f474c7b14feaad6", null ],
    [ "wiz_send_data", "group___basic___i_o__function.html#gab3dd6071b87bea9afcedcb57e248a7d0", null ],
    [ "WIZCHIP_READ", "group___basic___i_o__function.html#ga674a6dc857166809ddc71ea8d40d56b8", null ],
    [ "WIZCHIP_READ_BUF", "group___basic___i_o__function.html#ga07f86e715351564afb11298ed7a79381", null ],
    [ "WIZCHIP_WRITE", "group___basic___i_o__function.html#gabab850c3fe94043edcd8f13002f8ff6b", null ],
    [ "WIZCHIP_WRITE_BUF", "group___basic___i_o__function.html#gace1d7f17bb930589033e06e067888b2f", null ]
];