var union_____w_i_z_c_h_i_p_1_1___i_f =
[
    [ "_read_burst", "union_____w_i_z_c_h_i_p_1_1___i_f.html#a49f6936f4b08b4964da5c95c663aaaa3", null ],
    [ "_read_byte", "union_____w_i_z_c_h_i_p_1_1___i_f.html#a1b71333fad5727f0e7046be0f8729685", null ],
    [ "_read_data", "union_____w_i_z_c_h_i_p_1_1___i_f.html#acc77807dc001a1e57c6707967e308b9b", null ],
    [ "_write_burst", "union_____w_i_z_c_h_i_p_1_1___i_f.html#ae79f914272588fd0d3aad92fc41ec06d", null ],
    [ "_write_byte", "union_____w_i_z_c_h_i_p_1_1___i_f.html#a13486b4bb755a6d857d9b703030737a4", null ],
    [ "_write_data", "union_____w_i_z_c_h_i_p_1_1___i_f.html#ab4d87632c5594273edac71cb599ef041", null ],
    [ "BUS", "union_____w_i_z_c_h_i_p_1_1___i_f.html#aa47f986feaba2ded3bcc04dd6f21f401", null ],
    [ "SPI", "union_____w_i_z_c_h_i_p_1_1___i_f.html#ad831ac8703c57479eb0dd4f84f266377", null ]
];