var group___common__register__group =
[
    [ "_IMR_", "group___common__register__group.html#ga59d7d4b2fe43cce08b67aa1afcf1dce5", null ],
    [ "_RCR_", "group___common__register__group.html#gaf2db79579ab7a897bf3a4cc0694f8da3", null ],
    [ "_RTR_", "group___common__register__group.html#ga14fd22108c55f8cf86bf05e4418ba326", null ],
    [ "GAR", "group___common__register__group.html#ga4949d98617f16809c74f2382ebe9e2c8", null ],
    [ "INTLEVEL", "group___common__register__group.html#ga44cf25d713df4e47aa2e2129a80d2d81", null ],
    [ "IR", "group___common__register__group.html#ga68e22635ff207d8ca10459833856bd75", null ],
    [ "MR", "group___common__register__group.html#ga9ecbd9f86f95534f1bcf71015d5ae81a", null ],
    [ "PHAR", "group___common__register__group.html#ga3ed5558b8cfbba78bf63fb2b8c907c38", null ],
    [ "PHYCFGR", "group___common__register__group.html#ga7cc24f47ca8dcb311ade3a0bcbd74eaf", null ],
    [ "PMAGIC", "group___common__register__group.html#ga162ee07110c2c639f7fa2de585d65e23", null ],
    [ "PMRU", "group___common__register__group.html#ga5d3d5eb120bed5e04464780d82ca5f2e", null ],
    [ "PSID", "group___common__register__group.html#ga0220d54b2e7b00e196a7010a1cb25a58", null ],
    [ "PTIMER", "group___common__register__group.html#ga29dd564a4c90f2efa7cc7ee03ddba7d5", null ],
    [ "SHAR", "group___common__register__group.html#ga2786df906e3569b2b578ecebfaabde15", null ],
    [ "SIMR", "group___common__register__group.html#gaf08cda69b65a0f84ca02edfb131ac82a", null ],
    [ "SIPR", "group___common__register__group.html#gac1017606925e844389f81ccc7fc7799b", null ],
    [ "SIR", "group___common__register__group.html#ga3afb7d25f6248e33771faa1bff574d4a", null ],
    [ "SUBR", "group___common__register__group.html#ga49fe7cfa44021aa3ad5ba1f15f7809eb", null ],
    [ "UIPR", "group___common__register__group.html#ga6ce7e2945cd7d83c6f8c7f97bd9c27b0", null ],
    [ "UPORTR", "group___common__register__group.html#gaab2aaf717d74299303b89630ee2c7ecb", null ],
    [ "VERSIONR", "group___common__register__group.html#ga4e029565150c3aca3ba16b2ae3ea8b4e", null ]
];