var structwiz___net_timeout__t =
[
    [ "retry_cnt", "structwiz___net_timeout__t.html#a2bdee10b315515da8d39dc8d7a4a61e2", null ],
    [ "time_100us", "structwiz___net_timeout__t.html#a96d09210d9b4bc0a4424eddd75495314", null ]
];