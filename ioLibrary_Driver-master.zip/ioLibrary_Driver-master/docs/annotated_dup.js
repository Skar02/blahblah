var annotated_dup =
[
    [ "__WIZCHIP", "struct_____w_i_z_c_h_i_p.html", "struct_____w_i_z_c_h_i_p" ],
    [ "wiz_NetInfo_t", "structwiz___net_info__t.html", "structwiz___net_info__t" ],
    [ "wiz_NetTimeout_t", "structwiz___net_timeout__t.html", "structwiz___net_timeout__t" ],
    [ "wiz_PhyConf_t", "structwiz___phy_conf__t.html", "structwiz___phy_conf__t" ]
];