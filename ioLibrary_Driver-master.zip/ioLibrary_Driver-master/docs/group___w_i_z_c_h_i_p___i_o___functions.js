var group___w_i_z_c_h_i_p___i_o___functions =
[
    [ "Basic I/O function", "group___basic___i_o__function.html", "group___basic___i_o__function" ],
    [ "Common register access functions", "group___common__register__access__function.html", "group___common__register__access__function" ],
    [ "Socket register access functions", "group___socket__register__access__function.html", "group___socket__register__access__function" ]
];