var searchData=
[
  ['id_502',['id',['../struct_____w_i_z_c_h_i_p.html#a836d635c51ae68815e49464836c09912',1,'__WIZCHIP']]],
  ['if_5fmode_503',['if_mode',['../struct_____w_i_z_c_h_i_p.html#a756c793b5c41636ebdf090d7c4d3ea00',1,'__WIZCHIP']]],
  ['ip_504',['ip',['../structwiz___net_info__t.html#ae81515e082f9bc33e8968181945586da',1,'wiz_NetInfo_t']]]
];
