var searchData=
[
  ['getsn_5frxmax_604',['getSn_RxMAX',['../w5500_8h.html#a6ea2cfdeb5b8fb71ff05db08990e0df4',1,'w5500.h']]],
  ['getsn_5ftxmax_605',['getSn_TxMAX',['../w5500_8h.html#aba5cffa90ce609d64d0027285d41336d',1,'w5500.h']]]
];
