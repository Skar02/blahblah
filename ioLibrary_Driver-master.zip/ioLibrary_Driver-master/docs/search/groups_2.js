var searchData=
[
  ['basic_20i_2fo_20function_713',['Basic I/O function',['../group___basic___i_o__function.html',1,'']]]
];
