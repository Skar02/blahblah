var searchData=
[
  ['wiz_5fnetinfo_5ft_426',['wiz_NetInfo_t',['../structwiz___net_info__t.html',1,'']]],
  ['wiz_5fnettimeout_5ft_427',['wiz_NetTimeout_t',['../structwiz___net_timeout__t.html',1,'']]],
  ['wiz_5fphyconf_5ft_428',['wiz_PhyConf_t',['../structwiz___phy_conf__t.html',1,'']]]
];
