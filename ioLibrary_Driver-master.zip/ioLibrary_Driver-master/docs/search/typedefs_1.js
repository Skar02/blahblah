var searchData=
[
  ['wiz_5fnetinfo_514',['wiz_NetInfo',['../group___d_a_t_a___t_y_p_e.html#ga2ff9b34f5647319803e5d63f970728c9',1,'wizchip_conf.h']]],
  ['wiz_5fnettimeout_515',['wiz_NetTimeout',['../group___d_a_t_a___t_y_p_e.html#ga6a2040213546a67cffd2e9333f59cbc3',1,'wizchip_conf.h']]],
  ['wiz_5fphyconf_516',['wiz_PhyConf',['../group___d_a_t_a___t_y_p_e.html#gac40ecf56c0038249b1431f63a925427b',1,'wizchip_conf.h']]]
];
