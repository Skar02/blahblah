var searchData=
[
  ['ctlnetwork_5ftype_517',['ctlnetwork_type',['../group___d_a_t_a___t_y_p_e.html#gabc27f589bbab92c248e76e7d15eb31e8',1,'wizchip_conf.h']]],
  ['ctlsock_5ftype_518',['ctlsock_type',['../group___d_a_t_a___t_y_p_e.html#ga3a77339a724cf087b366b8710aa683e6',1,'socket.h']]],
  ['ctlwizchip_5ftype_519',['ctlwizchip_type',['../group___d_a_t_a___t_y_p_e.html#gaca023f09ee4830a55aa38846e1bb3b44',1,'wizchip_conf.h']]]
];
