var searchData=
[
  ['data_20type_68',['DATA TYPE',['../group___d_a_t_a___t_y_p_e.html',1,'']]],
  ['dhcp_69',['dhcp',['../structwiz___net_info__t.html#aff5d1c06cc07180717f38809f922fb35',1,'wiz_NetInfo_t']]],
  ['dhcp_5fmode_70',['dhcp_mode',['../group___d_a_t_a___t_y_p_e.html#ga76e5aa4ff40d1cb562e46e3bf9b1e9d1',1,'wizchip_conf.h']]],
  ['disconnect_71',['disconnect',['../group___w_i_znet__socket___a_p_is.html#ga0230efb936b222a0cbc7680e2c39c994',1,'disconnect(uint8_t sn):&#160;socket.c'],['../group___w_i_znet__socket___a_p_is.html#ga0230efb936b222a0cbc7680e2c39c994',1,'disconnect(uint8_t sn):&#160;socket.c']]],
  ['dns_72',['dns',['../structwiz___net_info__t.html#a9bf249fa42db4caf84d05f92ed1f9718',1,'wiz_NetInfo_t']]],
  ['duplex_73',['duplex',['../structwiz___phy_conf__t.html#a9296ce83c568e13e59d7c33283886601',1,'wiz_PhyConf_t']]]
];
