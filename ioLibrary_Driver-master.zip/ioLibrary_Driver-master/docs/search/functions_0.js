var searchData=
[
  ['close_435',['close',['../group___w_i_znet__socket___a_p_is.html#gaf7c8a46c623edfab31d9e09788394b2f',1,'close(uint8_t sn):&#160;socket.c'],['../group___w_i_znet__socket___a_p_is.html#gaf7c8a46c623edfab31d9e09788394b2f',1,'close(uint8_t sn):&#160;socket.c']]],
  ['connect_436',['connect',['../group___w_i_znet__socket___a_p_is.html#gaf7ab832f4201ef0f04eefcac063b998e',1,'connect(uint8_t sn, uint8_t *addr, uint16_t port):&#160;socket.c'],['../group___w_i_znet__socket___a_p_is.html#gaf7ab832f4201ef0f04eefcac063b998e',1,'connect(uint8_t sn, uint8_t *addr, uint16_t port):&#160;socket.c']]],
  ['ctlnetwork_437',['ctlnetwork',['../group__extra__functions.html#ga315235b3215e09b1230f4fae093a26b3',1,'ctlnetwork(ctlnetwork_type cntype, void *arg):&#160;wizchip_conf.c'],['../group__extra__functions.html#ga315235b3215e09b1230f4fae093a26b3',1,'ctlnetwork(ctlnetwork_type cntype, void *arg):&#160;wizchip_conf.c']]],
  ['ctlsocket_438',['ctlsocket',['../group___w_i_znet__socket___a_p_is.html#gae2f94d7d4ce040f6bf68779e064d224e',1,'ctlsocket(uint8_t sn, ctlsock_type cstype, void *arg):&#160;socket.c'],['../group___w_i_znet__socket___a_p_is.html#gae2f94d7d4ce040f6bf68779e064d224e',1,'ctlsocket(uint8_t sn, ctlsock_type cstype, void *arg):&#160;socket.c']]],
  ['ctlwizchip_439',['ctlwizchip',['../group__extra__functions.html#ga0ff8fc15549599a1d08dc5ec378779d9',1,'ctlwizchip(ctlwizchip_type cwtype, void *arg):&#160;wizchip_conf.c'],['../group__extra__functions.html#ga0ff8fc15549599a1d08dc5ec378779d9',1,'ctlwizchip(ctlwizchip_type cwtype, void *arg):&#160;wizchip_conf.c']]]
];
