var searchData=
[
  ['dhcp_498',['dhcp',['../structwiz___net_info__t.html#aff5d1c06cc07180717f38809f922fb35',1,'wiz_NetInfo_t']]],
  ['dns_499',['dns',['../structwiz___net_info__t.html#a9bf249fa42db4caf84d05f92ed1f9718',1,'wiz_NetInfo_t']]],
  ['duplex_500',['duplex',['../structwiz___phy_conf__t.html#a9296ce83c568e13e59d7c33283886601',1,'wiz_PhyConf_t']]]
];
