var searchData=
[
  ['wizchip_5fcritical_5fenter_709',['WIZCHIP_CRITICAL_ENTER',['../w5500_8h.html#ac59d6ec9327da0fd3ea8fa3fd21b9701',1,'w5500.h']]],
  ['wizchip_5fcritical_5fexit_710',['WIZCHIP_CRITICAL_EXIT',['../w5500_8h.html#a0bfaa1b1d5c9582dddf46b6265b96ab7',1,'w5500.h']]]
];
