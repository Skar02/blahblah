var searchData=
[
  ['versionr_369',['VERSIONR',['../group___common__register__group.html#ga4e029565150c3aca3ba16b2ae3ea8b4e',1,'w5500.h']]]
];
