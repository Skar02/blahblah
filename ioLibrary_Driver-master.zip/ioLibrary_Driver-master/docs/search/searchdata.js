var indexSectionsWithContent =
{
  0: "12_bcdgilmnprstuvw",
  1: "_w",
  2: "sw",
  3: "cdglrsw",
  4: "_bdgimrstw",
  5: "_w",
  6: "cdins",
  7: "cins",
  8: "_gimpsw",
  9: "12bcdsw",
  10: "it"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Modules",
  10: "Pages"
};

