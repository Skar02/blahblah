var searchData=
[
  ['_5f_5fwizchip_422',['__WIZCHIP',['../struct_____w_i_z_c_h_i_p.html',1,'']]],
  ['_5fcris_423',['_CRIS',['../struct_____w_i_z_c_h_i_p_1_1___c_r_i_s.html',1,'__WIZCHIP']]],
  ['_5fcs_424',['_CS',['../struct_____w_i_z_c_h_i_p_1_1___c_s.html',1,'__WIZCHIP']]],
  ['_5fif_425',['_IF',['../union_____w_i_z_c_h_i_p_1_1___i_f.html',1,'__WIZCHIP']]]
];
