var searchData=
[
  ['mac_505',['mac',['../structwiz___net_info__t.html#a2f32c75fb4bc7ba39243ef4a9f8eacc1',1,'wiz_NetInfo_t']]],
  ['mode_506',['mode',['../structwiz___phy_conf__t.html#a37e90f5e3bd99fac2021fb3a326607d4',1,'wiz_PhyConf_t']]]
];
