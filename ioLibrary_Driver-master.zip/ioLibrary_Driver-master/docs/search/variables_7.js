var searchData=
[
  ['sn_508',['sn',['../structwiz___net_info__t.html#aa73e8ce077be99a42405230770f2c731',1,'wiz_NetInfo_t']]],
  ['speed_509',['speed',['../structwiz___phy_conf__t.html#aae32029df16a54aa86c0aec2df9f7bb7',1,'wiz_PhyConf_t']]],
  ['spi_510',['SPI',['../union_____w_i_z_c_h_i_p_1_1___i_f.html#ad831ac8703c57479eb0dd4f84f266377',1,'__WIZCHIP::_IF']]]
];
