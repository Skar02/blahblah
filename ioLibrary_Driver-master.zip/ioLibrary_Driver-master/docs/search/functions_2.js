var searchData=
[
  ['getsn_5frx_5frsr_441',['getSn_RX_RSR',['../group___socket__register__access__function.html#ga321fbcdaf88299f5c4022314376e4e74',1,'getSn_RX_RSR(uint8_t sn):&#160;w5500.c'],['../group___socket__register__access__function.html#ga321fbcdaf88299f5c4022314376e4e74',1,'getSn_RX_RSR(uint8_t sn):&#160;w5500.c']]],
  ['getsn_5ftx_5ffsr_442',['getSn_TX_FSR',['../group___socket__register__access__function.html#gadd5918adebaa3744ddc01a76c84a894a',1,'getSn_TX_FSR(uint8_t sn):&#160;w5500.c'],['../group___socket__register__access__function.html#gadd5918adebaa3744ddc01a76c84a894a',1,'getSn_TX_FSR(uint8_t sn):&#160;w5500.c']]],
  ['getsockopt_443',['getsockopt',['../group___w_i_znet__socket___a_p_is.html#ga631998ae17cbf099b0071f20c88ce5cf',1,'getsockopt(uint8_t sn, sockopt_type sotype, void *arg):&#160;socket.c'],['../group___w_i_znet__socket___a_p_is.html#ga631998ae17cbf099b0071f20c88ce5cf',1,'getsockopt(uint8_t sn, sockopt_type sotype, void *arg):&#160;socket.c']]]
];
