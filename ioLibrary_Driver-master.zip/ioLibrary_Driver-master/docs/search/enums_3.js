var searchData=
[
  ['netmode_5ftype_522',['netmode_type',['../group___d_a_t_a___t_y_p_e.html#ga7543c641a8f3ad6dce26f2387e7e8eac',1,'wizchip_conf.h']]]
];
