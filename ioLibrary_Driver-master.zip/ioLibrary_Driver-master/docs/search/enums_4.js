var searchData=
[
  ['sockint_5fkind_523',['sockint_kind',['../group___d_a_t_a___t_y_p_e.html#gaa9d536c54137cd7b425c4c1e3cbfd49c',1,'socket.h']]],
  ['sockopt_5ftype_524',['sockopt_type',['../group___d_a_t_a___t_y_p_e.html#ga2f86b7ad233f3b8d6ae0af3ee91e9944',1,'socket.h']]]
];
