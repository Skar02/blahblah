var searchData=
[
  ['data_20type_716',['DATA TYPE',['../group___d_a_t_a___t_y_p_e.html',1,'']]]
];
