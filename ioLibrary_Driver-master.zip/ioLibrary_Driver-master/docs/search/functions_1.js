var searchData=
[
  ['disconnect_440',['disconnect',['../group___w_i_znet__socket___a_p_is.html#ga0230efb936b222a0cbc7680e2c39c994',1,'disconnect(uint8_t sn):&#160;socket.c'],['../group___w_i_znet__socket___a_p_is.html#ga0230efb936b222a0cbc7680e2c39c994',1,'disconnect(uint8_t sn):&#160;socket.c']]]
];
