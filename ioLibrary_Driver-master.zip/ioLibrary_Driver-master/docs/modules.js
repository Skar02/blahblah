var modules =
[
    [ "1. WIZnet socket APIs", "group___w_i_znet__socket___a_p_is.html", "group___w_i_znet__socket___a_p_is" ],
    [ "DATA TYPE", "group___d_a_t_a___t_y_p_e.html", "group___d_a_t_a___t_y_p_e" ],
    [ "2. WIZnet Extra Functions", "group__extra__functions.html", "group__extra__functions" ],
    [ "W5500", "group___w5500.html", "group___w5500" ]
];