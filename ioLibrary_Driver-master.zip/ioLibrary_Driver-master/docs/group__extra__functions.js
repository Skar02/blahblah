var group__extra__functions =
[
    [ "ctlnetwork", "group__extra__functions.html#ga315235b3215e09b1230f4fae093a26b3", null ],
    [ "ctlwizchip", "group__extra__functions.html#ga0ff8fc15549599a1d08dc5ec378779d9", null ],
    [ "wizchip_clrinterrupt", "group__extra__functions.html#ga41f91261077bc64e240d506923c29181", null ],
    [ "wizchip_getinterrupt", "group__extra__functions.html#gae5858fe7ca3d498e9fec4c3457a02e2e", null ],
    [ "wizchip_getinterruptmask", "group__extra__functions.html#ga54ab95788a37781b24e2279022a8705b", null ],
    [ "wizchip_getnetinfo", "group__extra__functions.html#ga769cf8bbf0e35981777977e37443c766", null ],
    [ "wizchip_getnetmode", "group__extra__functions.html#ga0313b6a7ced290f618912bf9de7791ab", null ],
    [ "wizchip_gettimeout", "group__extra__functions.html#ga05f7ba1f50d0cb7a7db4207af9182644", null ],
    [ "wizchip_init", "group__extra__functions.html#ga1bd1977c0db22c93e1841f8353dd919e", null ],
    [ "wizchip_setinterruptmask", "group__extra__functions.html#gafb30bdc1c5333b6bb67bdd20399b0f38", null ],
    [ "wizchip_setnetinfo", "group__extra__functions.html#gaf581fa9246e4a5621936c7b83d18a0fa", null ],
    [ "wizchip_setnetmode", "group__extra__functions.html#gac4f457e87b5f9db2eccebb790a348e8c", null ],
    [ "wizchip_settimeout", "group__extra__functions.html#ga91ca4b3716c77ed5a6a32757c53f7a02", null ],
    [ "wizchip_sw_reset", "group__extra__functions.html#ga4033269f88b0e202837c4c56a1d8d437", null ],
    [ "wizphy_getphyconf", "group__extra__functions.html#ga4745d0ce5551dd24df8550d4e0602aec", null ],
    [ "wizphy_getphystat", "group__extra__functions.html#ga6ab08d93c02389fe12590ba0c677a965", null ],
    [ "wizphy_setphyconf", "group__extra__functions.html#ga60359c86bf85ccd5ca8f6e7cafc849dc", null ],
    [ "wizphy_setphypmode", "group__extra__functions.html#ga64a4fd3427b5c5f43a3f35fb433cb06c", null ]
];